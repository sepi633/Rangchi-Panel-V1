import{_ as e,c,o as n}from"./Cz57ZvtP.js";const o={};function r(t,s){return n(),c("div",null,"ok")}const a=e(o,[["render",r]]);export{a as default};
