function r(){return{getCode:async t=>{try{const e=await $fetch("/api/code/code",{method:"GET",query:{CodeGroupLabel:t}});return e==null?void 0:e.list}catch{return[]}}}}export{r as u};
