import{_,c,o}from"./Cz57ZvtP.js";const e={},n={class:"loading"};function t(s,a){return o(),c("div",n)}const d=_(e,[["render",t],["__scopeId","data-v-a2ad9840"]]);export{d as _};
