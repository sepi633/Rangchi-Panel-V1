import{K as o}from"./Cz57ZvtP.js";const p=o("/img/logo.png");export{p as _};
