import{_ as De}from"./28USu4p-.js";import{_ as Se}from"./CLl0F9Zh.js";import{_ as Ve,p as Ne,r as h,v as _e,s as Be,c as y,o as _,a as e,t as n,l,b as r,w as p,J as Ie,F as ve,B as xe,W as $e,h as Fe,q as ge,i as Oe,n as Ue,y as be,z as ye,k as Ce,x as Ee,d as E,D as Le,H as Te}from"./Cz57ZvtP.js";import{_ as ze}from"./BI05Hs2X.js";import{_ as Re}from"./CzflAsPA.js";import{_ as Me}from"./D15-AZUe.js";import{_ as qe}from"./w1PXhIs5.js";import{_ as je}from"./pSRIsp47.js";import{m as Ye}from"./BFHa4Bs4.js";import"./CobJV7r0.js";import"./Dyy5udzH.js";import"./CuhzvVNj.js";import"./CDUvg8DA.js";import"./MfVpmBq8.js";const Ge={class:"hidden",id:"printArea"},He={class:"print"},Ae={class:"card flex"},Je={class:"flex between w"},We={class:"p"},Ke={class:"p"},Qe={class:"p"},Xe={class:"card flex"},Ze={class:"flex between w"},et={class:"p"},tt={class:"p"},ot={class:"card flex"},at={class:"flex between w"},lt={class:"p"},nt={class:"p"},st={class:"p"},rt={class:"p"},dt={class:"card flex"},it={class:"flex between w"},ut={class:"p"},ft={class:"p"},ct={class:"card"},mt={class:"title center"},pt={class:"p"},kt={__name:"order",props:["order","time"],setup(s){const{public:{projectName:B}}=Ne(),w=s,Y=h([]),g=h({});_e(async()=>{await S()});function L(){var i=window.open("","PRINT","");i.document.write(`<html><head>
      <title>${document.title} '</title><style >
  
   @media print {
        @page {
        size: portrait;
        }
      table {page-break-inside: avoid;}
    }
  
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 100;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-thin.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-thin.woff2') format('woff2');		
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 300;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-Light.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakh-Light.woff2') format('woff2');	
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: normal;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-Regular.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-Regular.woff2') format('woff2');		 
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 600;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-SemiBold.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-SemiBold.woff2') format('woff2');		 
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: bold;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-Bold.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-Bold.woff2') format('woff2'); 
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 800;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-ExtraBold.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-ExtraBold.woff2') format('woff2');		 
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 900;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-Black.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-Black.woff2') format('woff2');		 
  }
  
  @font-face {
      font-family: YekanBakh;
      font-style: normal;
      font-weight: 950;
      src: url('/fonts/YekanBakh_Pro/woff/YekanBakhFaNum-ExtraBlack.woff') format('woff'),   
      url('/fonts/YekanBakh_Pro/woff2/YekanBakhFaNum-ExtraBlack.woff2') format('woff2');		 
  }
  
  body{
      direction: rtl;
      background-color: #f9f9f9;
  }
  
  * {
      font-family: 'YekanBakh' !important;
  }
  
  .header {
   background-color: #f9f9f9;
  position:fixed;
  top:0;
    width: 100%;
    height: 100px;
    display: flex;
    justify-content: start;
    align-items: center;
  }
  .w {
    width: 100%;
  }
    main{
    width:100%
    }
  .title {
    font-size: large;
    font-weight: 600;
  }
  .center {
    text-align: center;
  }
  .green {
    color: #39706d;
  }
  .between {
    justify-content: space-between;
    align-items: center;
  }
  .header img {
    height: 100%;
    width: auto;
  }
  .header .bar {
    height: 5px;
    width: 100%;
    background-color: #39706d;
  }
  main > * {
    margin: 10px 0;
  }
  .p {
    padding: 10px;
  }
  .print {
    min-height: 100vh;
    padding: 20px;
  }
  .flex {
    display: flex;
  }
  .card {
    padding: 10px 20px;
    border-radius: 16px;
    border: 1px solid #aaa;
  }
  .card .space {
    border-left: 1px solid #aaa;
    padding-left: 20px;
    min-width: 80px;
  }
  .footer {
   background-color: #f9f9f9;
    margin-top: auto;
    border-top: 6px solid #39706d;
    padding: 10px 0;
    text-align: center;
    font-weight: 600;
    color: #39706d;
    position:fixed;
    bottom:0;
    width:100%;
  }
  
  
  
  
  table {
    border: 1px solid #aaa;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 1rem;
    width: 100%;
  }
  td {
    border-top:  1px solid #aaa;
    border-left: 1px solid #ccc;
  }
  thead th{
    
    border-left: 1px solid #ccc;
  }
  thead th:last-child {
    border-left: unset
  
  }
  td,th{
    text-align: center;
    padding: 5px;
  }
   tr td:last-child {
  border-left: unset
  }
     </style>`),i.document.write("</head><body >"),i.document.write(document.getElementById("printArea").innerHTML),i.document.write("</body></html>"),i.focus()}Be(()=>w.time,async()=>{var i;(i=w==null?void 0:w.order)!=null&&i.id&&a(w.order.id).then(()=>{$e(()=>{L()})})},{deep:!0});const S=async()=>{try{const i=await $fetch("/api/details/baseDetails",{method:"GET"});i.list.length>0&&(g.value=i==null?void 0:i.list[0])}catch{}},a=async i=>{try{const t=await $fetch("/api/orders/productOrderStoreInfo",{method:"GET",query:{ProductOrderId:i}});Y.value=t.list}catch{}};return(i,t)=>{var b,V,c,o,v,k,f,x,N,I,$,F,O,U,C,d,m,z,R,M,q,j,G,H,A;const T=Ie;return _(),y("div",Ge,[e("div",He,[t[18]||(t[18]=e("div",{class:"header"},[e("div",{class:"bar"})],-1)),t[19]||(t[19]=e("br",null,null,-1)),e("main",null,[t[17]||(t[17]=e("div",{class:"title green center"},"صورتحساب فروش کالا",-1)),e("div",Ae,[t[0]||(t[0]=e("div",{class:"title space flex between"},"فروشنده",-1)),e("div",Je,[e("div",null,[e("div",We,"فروشنده : "+n(l(B)),1),e("div",Ke," آدرس : "+n((b=l(g))==null?void 0:b.addressValue),1)]),e("div",null,[e("div",Qe," تلفن : "+n((V=l(g))==null?void 0:V.postalCode),1)])])]),e("div",Xe,[t[1]||(t[1]=e("div",{class:"title space flex between"},"خریدار",-1)),e("div",Ze,[e("div",null,[e("div",et,"خریدار :"+n((o=(c=s.order)==null?void 0:c.user)==null?void 0:o.fullName),1)]),e("div",null,[e("div",tt,"تلفن : "+n((k=(v=s.order)==null?void 0:v.user)==null?void 0:k.mobile),1)])])]),e("div",ot,[t[2]||(t[2]=e("div",{class:"title space flex between"},"تحویل گیرنده",-1)),e("div",at,[e("div",null,[e("div",lt,"تحویل گیرنده :"+n(((x=(f=s.order)==null?void 0:f.address)==null?void 0:x.firstName)+((I=(N=s.order)==null?void 0:N.address)==null?void 0:I.lastName)),1),e("div",nt," آدرس :"+n(((U=(O=(F=($=s.order)==null?void 0:$.address)==null?void 0:F.city)==null?void 0:O.state)==null?void 0:U.name)+"-"+((m=(d=(C=s.order)==null?void 0:C.address)==null?void 0:d.city)==null?void 0:m.name))+" -"+n((R=(z=s.order)==null?void 0:z.address)==null?void 0:R.addressValue)+" ("+n((q=(M=s.order)==null?void 0:M.address)==null?void 0:q.name)+") ",1)]),e("div",null,[e("div",st,"تلفن : "+n((G=(j=s.order)==null?void 0:j.address)==null?void 0:G.mobile),1),e("div",rt,"کد پستی : "+n((A=(H=s.order)==null?void 0:H.address)==null?void 0:A.postalCode),1)])])]),e("div",dt,[e("div",it,[r(T,null,{default:p(()=>{var P,D;return[e("div",ut,"سفارش شماره :"+n((P=s.order)==null?void 0:P.id),1),e("div",ft,"تاریخ فاکتور : "+n(s.order.createDate&&l(Ye)((D=s.order)==null?void 0:D.createDate,"YYYY-MM-DD HH:mm:ss").locale("fa").format("YYYY/MM/DD")),1)]}),_:1})])]),e("div",ct,[(_(!0),y(ve,null,xe(l(Y),P=>{var D,J,W,K,Q,X,Z,ee,te,oe,ae,le,ne,se,re,de,ie;return _(),y("div",null,[e("div",mt,[e("div",pt," سفارشات فروشگاه : "+n((D=P.store)==null?void 0:D.name),1)]),e("table",null,[t[16]||(t[16]=e("thead",null,[e("th",null,"ردیف "),e("th",null,"نام محصول"),e("th",null,"ویژگی"),e("th",null,"قیمت "),e("th",null,"تخفیف "),e("th",null,"تعداد "),e("th",null,"جمع")],-1)),e("tbody",null,[(_(!0),y(ve,null,xe(P.productOrderItems,(u,Pe)=>{var ue,fe,ce,me,pe,ke,he,we;return _(),y("tr",{key:u==null?void 0:u.id},[e("td",null,n(Pe+1),1),e("td",null,n((fe=(ue=u.productItem)==null?void 0:ue.product)==null?void 0:fe.name),1),e("td",null,n((me=(ce=u.productItem)==null?void 0:ce.varietyItem)==null?void 0:me.varietyName)+" :"+n((ke=(pe=u.productItem)==null?void 0:pe.varietyItem)==null?void 0:ke.name),1),e("td",null,[t[3]||(t[3]=e("strong",{class:"lg:hidden"},"قیمت:",-1)),e("span",null,n((he=u==null?void 0:u.basePrice)==null?void 0:he.toLocaleString())+" تومان",1)]),e("td",null,n((we=u==null?void 0:u.discountPrice)==null?void 0:we.toLocaleString()),1),e("td",null,n(u==null?void 0:u.count),1),e("td",null,n(((u==null?void 0:u.count)*u.price).toLocaleString()),1)])}),128)),e("tr",null,[t[4]||(t[4]=e("td",{colspan:"5"},null,-1)),t[5]||(t[5]=e("td",null," قیمت ",-1)),e("td",null,n(((W=(J=s.order)==null?void 0:J.basePrice)==null?void 0:W.toLocaleString())+" تومان"),1)]),e("tr",null,[t[6]||(t[6]=e("td",{colspan:"5"},null,-1)),t[7]||(t[7]=e("td",null," هزینه ارسال ",-1)),e("td",null,n((K=s.order)!=null&&K.deliveryPrice?((X=(Q=s.order)==null?void 0:Q.deliveryPrice)==null?void 0:X.toLocaleString())+" تومان":0),1)]),e("tr",null,[t[8]||(t[8]=e("td",{colspan:"5"},null,-1)),t[9]||(t[9]=e("td",null," تخفیف کالا ",-1)),e("td",null,n((Z=s.order)!=null&&Z.discountPrice?((te=(ee=s.order)==null?void 0:ee.discountPrice)==null?void 0:te.toLocaleString())+" تومان":0),1)]),e("tr",null,[t[10]||(t[10]=e("td",{colspan:"5"},null,-1)),t[11]||(t[11]=e("td",null," کد تخفیف ",-1)),e("td",null,n((oe=s.order)!=null&&oe.rebatePrice?((le=(ae=s.order)==null?void 0:ae.rebatePrice)==null?void 0:le.toLocaleString())+" تومان":0),1)]),e("tr",null,[t[12]||(t[12]=e("td",{colspan:"5"},null,-1)),t[13]||(t[13]=e("td",null," ارزش افزوره ",-1)),e("td",null,n((ne=s.order)!=null&&ne.taxPrice?((re=(se=s.order)==null?void 0:se.taxPrice)==null?void 0:re.toLocaleString())+" تومان":0),1)]),e("tr",null,[t[14]||(t[14]=e("td",{colspan:"5"},null,-1)),t[15]||(t[15]=e("td",null," جمع کل ",-1)),e("td",null,n(((ie=(de=s.order)==null?void 0:de.paymentPrice)==null?void 0:ie.toLocaleString())+" تومان"),1)])])])])}),256))])]),t[20]||(t[20]=e("br",null,null,-1))])])}}},ht=Ve(kt,[["__scopeId","data-v-3348e951"]]),wt={class:"p-6 sm:p-10 space-y-6"},vt={class:"flex gap-2 items-center flex-wrap"},xt={class:"flex"},gt={class:"flex"},bt={class:"w-1/4 p-1"},yt=["placeholder"],_t={class:"flex flex-wrap justify-between items-center"},Bt={class:"text-sm leading-5"},Yt={class:"mx-2 font-bold"},Pt={class:"mx-2 font-bold"},Dt={class:"mx-2 font-bold"},Mt={__name:"index",setup(s){h(!0);const B=h({});h(!1);const w=h(!1),Y=Fe(),g=h(0),L=[{key:"id",label:"شماره سفارش"},{key:"user.fullName",label:"کاربر"},{key:"paymentPrice",label:"مبلغ سفارش "},{key:"createDate",label:"تاریخ"},{key:"isPaid",label:"وضعیت پرداخت"},{key:"productOrderState.name",label:"وضعیت "},{key:"productOrderStatus.name",label:" وضعیت ارسال "},{key:"isRepairShop",label:"عادی / سرویسکار"},{key:"actions"}],S=h([]),a=h({totalCount:0,pageIndex:1,pageSize:15,fromDate:null,toDate:null,ProductOrderStatusEnum:null,isPaid:null,q:null,rebateId:null}),i=ge(()=>(a.value.pageIndex-1)*a.value.pageSize+1),t=ge(()=>a.value.pageIndex*a.value.pageSize+1);h([]);const T=c=>[[{label:"ویرایش",icon:"i-heroicons-pencil-square-20-solid",click:()=>ye("/ProductOrder/insert"+c.id)}],[{label:"کالا های سفارش",icon:"i-heroicons-circle-stack",click:()=>ye("/ProductOrder/item-"+(c==null?void 0:c.id))}],[{label:"پرینت",icon:"i-heroicons-printer",click:()=>{B.value=c,g.value=Date.now()}}]];Be([()=>a.value.pageIndex,()=>a.value.isPaid,()=>a.value.rebateId,()=>a.value.q,()=>a.value.ProductOrderStatusEnumm,()=>a.value.fromDate,()=>a.value.toDate],async()=>{await b()});async function b(){var c,o,v,k;try{let f=JSON.parse(JSON.stringify(a.value));delete f.list,console.log(f);let x=await $fetch("/api/orders/orders",{method:"GET",query:f});a.value=x}catch(f){console.log(f),(o=(c=f==null?void 0:f.response)==null?void 0:c._data)!=null&&o.message?Y.add({description:(k=(v=f==null?void 0:f.response)==null?void 0:v._data)==null?void 0:k.message,title:"خطا !",color:"red"}):Y.add({description:"مشکلی پیش آمده است .",title:"خطا !",color:"red"})}}async function V(){try{let c=await $fetch("/api/rebate/rebate",{query:{pageSize:6e4}});S.value=c.list||[]}catch{}}return _e(()=>{b(),V()}),(c,o)=>{const v=De,k=Se,f=Oe("date-picker"),x=Ue,N=Ce,I=ze,$=Re,F=Me,O=qe,U=je,C=ht;return _(),y("div",wt,[r(U,null,{header:p(()=>[e("div",null,[o[10]||(o[10]=e("div",{class:"flex justify-between"},[e("p",null," مدیریت سفارشات"),e("div",{class:"flex justify-end"})],-1)),e("div",vt,[r(k,{class:"",label:"وضعیت"},{default:p(()=>[r(v,{modelValue:l(a).ProductOrderStatusEnum,"onUpdate:modelValue":o[0]||(o[0]=d=>l(a).ProductOrderStatusEnum=d),options:[{name:"همه",value:null},{name:"سفارش ثبت شده",value:0},{name:" در حال بررسی",value:1},{name:"ارسال به مشتری",value:2},{name:"تحویل به مشتری",value:3}],"option-attribute":"name","value-attribute":"value"},null,8,["modelValue"])]),_:1}),r(k,{class:"",label:"مالی"},{default:p(()=>[r(v,{modelValue:l(a).isPaid,"onUpdate:modelValue":o[1]||(o[1]=d=>l(a).isPaid=d),options:[{name:"همه",value:null},{name:"پرداخت شده",value:!0},{name:"پرداخت نشده",value:!1}],"option-attribute":"name","value-attribute":"value"},null,8,["modelValue"])]),_:1}),r(k,{class:"",label:"کد تخفیف"},{default:p(()=>[r(v,{modelValue:l(a).rebateId,"onUpdate:modelValue":o[2]||(o[2]=d=>l(a).rebateId=d),options:l(S),"option-attribute":"codeValue","value-attribute":"id"},null,8,["modelValue","options"])]),_:1}),r(k,{class:"flex gap-1",label:"از تاریخ"},{default:p(()=>[e("div",xt,[r(f,{locale:"fa",type:"date",modelValue:l(a).fromDate,"onUpdate:modelValue":o[3]||(o[3]=d=>l(a).fromDate=d)},null,8,["modelValue"]),r(x,{onClick:o[4]||(o[4]=d=>l(a).fromDate=null),name:"i-heroicons-x-mark-16-solid",class:"w-4 h-4 text-red-500"})])]),_:1}),r(k,{class:"flex gap-1",label:"تا تاریخ"},{default:p(()=>[e("div",gt,[r(f,{locale:"fa",type:"date",modelValue:l(a).toDate,"onUpdate:modelValue":o[5]||(o[5]=d=>l(a).toDate=d)},null,8,["modelValue"]),r(x,{name:"i-heroicons-x-mark-16-solid",class:"w-4 h-4 text-red-500",onClick:o[6]||(o[6]=d=>l(a).toDate=null)})])]),_:1}),e("div",bt,[Le(e("input",{class:"p-2 h-[40px] border rounded w-full",type:"text","onUpdate:modelValue":o[7]||(o[7]=d=>l(a).q=d),placeholder:c.$t("search")},null,8,yt),[[Te,l(a).q]])])])])]),footer:p(()=>[e("div",_t,[e("div",null,[e("span",Bt,[o[11]||(o[11]=E(" ردیف ")),e("span",Yt,n(l(i)),1),o[12]||(o[12]=E(" تا ")),e("span",Pt,n(l(t)),1),o[13]||(o[13]=E(" از ")),e("span",Dt,n(l(a).totalCount),1),o[14]||(o[14]=E(" مورد "))])]),r(O,{modelValue:l(a).pageIndex,"onUpdate:modelValue":o[9]||(o[9]=d=>l(a).pageIndex=d),"page-count":l(a).pageSize,total:l(a).totalCount,ui:{wrapper:"flex items-center flex-row-reverse gap-1",rounded:"!rounded-full min-w-[32px] justify-center",default:{activeButton:{variant:"outline"}}}},null,8,["modelValue","page-count","total"])])]),default:p(()=>{var d;return[r($,{rows:(d=l(a))==null?void 0:d.list,columns:L},{"actions-data":p(({row:m})=>[r(I,{items:T(m)},{default:p(()=>[r(N,{color:"gray",variant:"ghost",icon:"i-heroicons-ellipsis-horizontal-20-solid"})]),_:2},1032,["items"])]),"isPaid-data":p(({row:m})=>[r(x,{class:be([m.isPaid?"text-green-400":"text-red-400","w-8 h-8"]),size:"lg",name:m.isPaid?"i-heroicons-check-16-solid":"i-heroicons-x-mark-16-solid"},null,8,["class","name"])]),"isRepairShop-data":p(({row:m})=>[r(x,{class:be([m.isRepairShop?"text-green-400":"text-red-400","w-8 h-8"]),size:"lg",name:m.isRepairShop?"i-heroicons-check-16-solid":"i-heroicons-x-mark-16-solid"},null,8,["class","name"])]),"createDate-data":p(({row:m})=>[e("span",null,n(m.createDate?l(Ye)(m.createDate).locale("fa").format("YYYY/MM/DD"):""),1)]),_:1},8,["rows"]),r(F,{route:"/api/orders/order",formTitle:"سفارشات",onReload:b,selectedId:l(B).id,modelValue:l(w),"onUpdate:modelValue":o[8]||(o[8]=m=>Ee(w)?w.value=m:null)},null,8,["selectedId","modelValue"])]}),_:1}),r(C,{time:l(g),order:l(B)},null,8,["time","order"])])}}};export{Mt as default};
