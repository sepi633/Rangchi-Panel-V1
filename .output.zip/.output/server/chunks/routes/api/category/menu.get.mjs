import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const menu_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/CategoryMenu/${getQuery(event).id}`, {
      method: "GET",
      headers: {
        "Accept": "application/json"
      }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { menu_get as default };
//# sourceMappingURL=menu.get.mjs.map
