import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery, r as readBody, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const contactusGroup_post = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/ContactUsGroup`, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      },
      body: await readBody(event),
      query: getQuery(event)
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { contactusGroup_post as default };
//# sourceMappingURL=contactusGroup.post.mjs.map
