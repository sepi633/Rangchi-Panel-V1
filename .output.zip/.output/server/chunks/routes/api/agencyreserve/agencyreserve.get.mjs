import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const agencyreserve_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/AgencyReserve/${getQuery(event).userId}`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      }
      // query:{
      //     parentId:getQuery(event).parentId
      // }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { agencyreserve_get as default };
//# sourceMappingURL=agencyreserve.get.mjs.map
