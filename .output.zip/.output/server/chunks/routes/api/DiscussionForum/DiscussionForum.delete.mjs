import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const DiscussionForum_delete = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  await readBody(event);
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/DiscussionForum`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      },
      query: getQuery(event)
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { DiscussionForum_delete as default };
//# sourceMappingURL=DiscussionForum.delete.mjs.map
