import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const bank_delete = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/Bank`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`
      },
      query: {
        id: getQuery(event).id
      }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { bank_delete as default };
//# sourceMappingURL=bank.delete.mjs.map
