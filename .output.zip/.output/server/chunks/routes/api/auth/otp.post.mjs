import { c as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const otp_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const getCod = await $fetch(`${baseUrl}/api/Account/otp`, {
      method: "POST",
      body,
      headers: {
        Accept: "application/json",
        "Accept-Language": "fa-IR"
      }
    });
    return getCod;
  } catch (error) {
    return error;
  }
});

export { otp_post as default };
//# sourceMappingURL=otp.post.mjs.map
