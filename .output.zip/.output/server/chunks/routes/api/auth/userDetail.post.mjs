import { c as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const userDetail_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const response = await $fetch(`${baseUrl}/api/Account/userdetail`, {
      method: "POST",
      body: JSON.stringify(body),
      headers: {
        "accept": "*/*",
        "Accept-Language": "fa-IR",
        "Content-Type": "application/json"
      }
    });
    return response;
  } catch (error) {
    return error;
  }
});

export { userDetail_post as default };
//# sourceMappingURL=userDetail.post.mjs.map
