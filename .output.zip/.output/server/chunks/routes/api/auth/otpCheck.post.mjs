import { c as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const otpCheck_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const otpCheck = await $fetch(`${baseUrl}/api/Account/CheckOtp`, {
      method: "POST",
      body,
      headers: {
        Accept: "application/json",
        "Accept-Language": "fa-IR"
      }
    });
    return otpCheck;
  } catch (error) {
    return error;
  }
});

export { otpCheck_post as default };
//# sourceMappingURL=otpCheck.post.mjs.map
