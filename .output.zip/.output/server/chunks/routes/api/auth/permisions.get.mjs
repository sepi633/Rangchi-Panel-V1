import { c as defineEventHandler, u as useRuntimeConfig, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const permisions_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/EndUser/PermissionMenu`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { permisions_get as default };
//# sourceMappingURL=permisions.get.mjs.map
