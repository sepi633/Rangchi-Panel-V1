import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, g as getQuery } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const userRole_post = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const response = await $fetch(`${baseUrl}/api/Account/userRole`, {
      method: "post",
      query: getQuery(event),
      headers: {
        "accept": "*/*",
        "Accept-Language": "en-US",
        "Content-Type": "application/json"
      },
      body: await readBody(event)
    });
    return response;
  } catch (error) {
    console.log(error);
    return error;
  }
});

export { userRole_post as default };
//# sourceMappingURL=userRole.post.mjs.map
