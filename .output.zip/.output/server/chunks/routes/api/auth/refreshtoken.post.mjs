import { c as defineEventHandler, u as useRuntimeConfig, e as getCookie, r as readBody, f as setCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const refreshtoken_post = defineEventHandler(async (event) => {
  const { public: { baseUrl, testUrl } } = useRuntimeConfig();
  getCookie(event, "key");
  const body = await readBody(event);
  try {
    const login = await $fetch(`${baseUrl}/api/Account/refreshtoken`, {
      method: "POST",
      body,
      headers: {
        "accept": "*/*",
        "Content-Type": "application/json"
      }
    });
    if (login.isSuccess) {
      let now = /* @__PURE__ */ new Date();
      let rawExp = login.data.refreshTokenExp;
      let correctedExp = rawExp.replace(/(\.\d{3})\d+Z$/, "$1Z");
      let reftexp = new Date(correctedExp);
      const refdiffMs = reftexp.getTime() - now.getTime();
      setCookie(event, "key", login.data.token, {
        maxAge: refdiffMs / 1e3,
        path: "/"
      });
      setCookie(event, "rkey", login.data.refreshToken, {
        maxAge: refdiffMs / 1e3,
        path: "/"
      });
    }
    return login;
  } catch (error) {
    return error;
  }
});

export { refreshtoken_post as default };
//# sourceMappingURL=refreshtoken.post.mjs.map
