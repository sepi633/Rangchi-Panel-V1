import { c as defineEventHandler, u as useRuntimeConfig, e as getCookie, r as readBody } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const edit_put = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  const token = `Bearer ${getCookie(event, "key")}`;
  const body = await readBody(event);
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/CategoryComment`, {
      method: "PUT",
      headers: {
        "Accept": "application/json",
        "Authorization": `${token}`
      },
      body: JSON.stringify(body)
    });
    return data;
  } catch (error) {
    console.log("ERROR from nuxt api:" + error);
    return error;
  }
});

export { edit_put as default };
//# sourceMappingURL=edit.put.mjs.map
