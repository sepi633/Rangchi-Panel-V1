import { c as defineEventHandler, u as useRuntimeConfig, e as getCookie, g as getQuery } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const comments_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  const token = `Bearer ${getCookie(event, "key")}`;
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/CategoryComment`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `${token}`
      },
      query: getQuery(event)
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { comments_get as default };
//# sourceMappingURL=comments.get.mjs.map
