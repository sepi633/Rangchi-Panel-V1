import { c as defineEventHandler, u as useRuntimeConfig, e as getCookie, g as getQuery } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const comment_get = defineEventHandler(async (event) => {
  var _a;
  const { public: { baseUrl } } = useRuntimeConfig();
  const token = `Bearer ${getCookie(event, "key")}`;
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/CategoryComment/${(_a = getQuery(event)) == null ? void 0 : _a.id}`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `${token}`
      }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { comment_get as default };
//# sourceMappingURL=comment.get.mjs.map
