import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const form_delete = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  await readBody(event);
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/Form`, {
      method: "DELETE",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "en-US"
      },
      query: {
        id: getQuery(event).id
      }
    });
    return data;
  } catch (error) {
    return error;
  }
  return "body";
});

export { form_delete as default };
//# sourceMappingURL=form.delete.mjs.map
