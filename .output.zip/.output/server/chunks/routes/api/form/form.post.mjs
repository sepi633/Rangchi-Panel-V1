import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const form_post = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  const body = await readBody(event);
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/Form`, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "en-US"
      },
      body
    });
    return data;
  } catch (error) {
    return error;
  }
  return "body";
});

export { form_post as default };
//# sourceMappingURL=form.post.mjs.map
