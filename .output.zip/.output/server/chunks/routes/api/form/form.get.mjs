import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const form_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  const query = getQuery(event);
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/Form/${query.id}`, {
      method: "GET",
      headers: {
        "Accept": "text/plain",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "en-US"
      }
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { form_get as default };
//# sourceMappingURL=form.get.mjs.map
