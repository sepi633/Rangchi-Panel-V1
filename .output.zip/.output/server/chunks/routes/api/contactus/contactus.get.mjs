import { c as defineEventHandler, u as useRuntimeConfig, g as getQuery, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const contactus_get = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  try {
    const data = await $fetch(`${baseUrl}/api/Admin/ContactUs`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      },
      query: getQuery(event)
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { contactus_get as default };
//# sourceMappingURL=contactus.get.mjs.map
