import { c as defineEventHandler, u as useRuntimeConfig, r as readBody, e as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'node:crypto';
import 'consola';
import 'node:path';

const day_post = defineEventHandler(async (event) => {
  const { public: { baseUrl } } = useRuntimeConfig();
  const body = await readBody(event);
  try {
    const data = await $fetch(`${baseUrl}/api/admin/AgencyWorkDay`, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "AUTHORIZATION": `Bearer ${getCookie(event, "key")}`,
        "Accept-Language": "fa-IR"
      },
      body
    });
    return data;
  } catch (error) {
    return error;
  }
});

export { day_post as default };
//# sourceMappingURL=day.post.mjs.map
